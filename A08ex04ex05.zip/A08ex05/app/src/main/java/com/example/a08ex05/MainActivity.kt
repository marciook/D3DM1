package com.example.a08ex05

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    var resultado = 0
    private var score = 0
    lateinit var txtResultado: TextView
    lateinit var btnNovo: Button

    //val sharedPref = activity?.getPreferences(Context.MODE_PRIVATE) ?: return
    //val defaultValue = resources.getInteger(R.integer.saved_high_score_default_key)
    //val HighScore = sharedPref.getInt(getString(R.string.saved_high_score_key), defaultValue)
    val sharedPreference =  getSharedPreferences("SCORE",Context.MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        txtResultado = findViewById(R.id.txtResultado)
        btnNovo = findViewById(R.id.btnNovo)

        novoJogo()

    }
    private fun novoJogo(){
        txtResultado.text = "Par ou Ímpar?"
        resultado = Random.nextInt(0,10)
        btnNovo.visibility = View.INVISIBLE
    }

    fun novoJogo(view: View){
        novoJogo()
    }

    fun jogada(view: View){
        if (resultado % 2 == view.tag.toString().toInt())
            if (btnNovo.visibility == View.INVISIBLE)
                score++
                getPreferences(MODE_PRIVATE).edit().putInt("SCORE",score).commit()
        title = "Score: $score"
        txtResultado.text = "$resultado"
        btnNovo.visibility = View.VISIBLE
    }
}